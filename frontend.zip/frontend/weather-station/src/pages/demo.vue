<template>
  <v-app>
    <v-navigation-drawer app>
      <v-list>
        <v-list-item active-class="active">
          <v-list-item-icon>
            <v-icon>mdi-view-dashboard</v-icon>
          </v-list-item-icon>
          <v-list-item-title>Dashboard</v-list-item-title>
        </v-list-item>
        <v-list-item active-class="active">
          <v-list-item-icon>
            <v-icon>mdi-home</v-icon>
          </v-list-item-icon>
          <v-list-item-title>Live</v-list-item-title>
        </v-list-item>
        <v-list-item active-class="active">
          <v-list-item-icon>
            <v-icon>mdi-chart-bar</v-icon>
          </v-list-item-icon>
          <v-list-item-title>Analysis</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar app>
      <v-app-bar-nav-icon></v-app-bar-nav-icon>
      <v-toolbar-title>Weather Station</v-toolbar-title>
      <v-spacer></v-spacer>
      <v-btn icon>
        <v-icon>mdi-feature</v-icon>
      </v-btn>
    </v-app-bar>

    <v-main>
      <v-container>
        <v-row>
          <v-col cols="6">
            <v-card>
              <v-card-title>Graph</v-card-title>
              <v-card-text>
                <!-- Bar graph content here -->
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="6">
            <v-card>
              <v-card-title>Chart</v-card-title>
              <v-card-text>
                <!-- Pie chart content here -->
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>

        <v-row justify="center">
          <v-col cols="4">
            <v-card>
              <v-card-title>Card 1</v-card-title>
              <v-card-text>
                <!-- Card 1 content here -->
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="4">
            <v-card>
              <v-card-title>Card 2</v-card-title>
              <v-card-text>
                <!-- Card 2 content here -->
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="4">
            <v-card>
              <v-card-title>Card 3</v-card-title>
              <v-card-text>
                <!-- Card 3 content here -->
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-container>

      <v-container>
        <v-card-text>
          <div id="fluid-meter"></div>
        </v-card-text>
      </v-container>
    </v-main>

    <v-footer app>
      &copy; Weather Station 2024. All rights reserved
    </v-footer>
  </v-app>
</template>

<script>
export default {
  name: 'home-index',
}
</script>

<style scoped>
.active {
  background-color: green; /* Change this to the color you want */
}
</style>